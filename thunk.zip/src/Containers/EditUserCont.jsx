import React, { Component } from 'react'
import { BackComp } from '../components/BackComp'

export default class EditUserCont extends Component {
  render() {
    return (
      <div>
        <h1>Edit User</h1>
        <BackComp/>
      </div>
    )
  }
}
