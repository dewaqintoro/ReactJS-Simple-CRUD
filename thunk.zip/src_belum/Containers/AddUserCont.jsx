import React, { Component } from 'react'
import { BackComp } from '../components/BackComp'

export default class AddUserCont extends Component {
  render() {
    return (
      <div>
        <h1>Add User</h1>
        <BackComp/>
      </div>
    )
  }
}
