import React, { Component } from 'react'
import TableComp from '../components/TableComp'

export default class HomeCont extends Component {
  render() {
    return (
      <div>
        <h1>Home</h1>
        <TableComp users={this.props.users}/>
      </div>
    )
  }
}
