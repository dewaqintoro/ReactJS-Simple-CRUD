import React, { Component } from 'react'
import { BackComp } from '../components/BackComp'

export default class DetailUserCont extends Component {
  render() {
    return (
      <div>
        <h1>Detail</h1>
        <BackComp/>
      </div>
    )
  }
}
